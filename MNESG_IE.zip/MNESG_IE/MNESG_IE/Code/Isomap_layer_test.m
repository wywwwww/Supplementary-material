function [sampleset_pair]=Isomap_layer_test(train_data,test_data,k)

Dd=train_data;
Ddt=test_data;
% step1: Calculate the k nearest distance 
[m, ~] = size(Dd); %d<~
[n, ~] = size(Ddt); %d<~
X=Ddt;
trainx=Dd;
D = zeros(n,m);
for i =1 : n
    xx = repmat(X(i, :), m, 1);
    diff = xx - trainx;
    dist = sum(diff.* diff, 2);
    [~, pos] = sort(dist);%posΪ��ţ�ddΪ��Ӧ��ֵ
    index = pos(1 : k + 1)';%���Լ������k������
    index2 = pos(k + 2 : m);
    D(i,index) = sqrt(dist(index));
    D(i,index2) = inf;
end
%step2: recalculate shortest distant matrix
s=min(m,n);
for t=1:s
    for i=1:n
        for j=1:m
            if D(i,j)>D(i,t)+D(t,j)
                D(i,j)=D(i,t)+D(t,j);
            end
        end
    end
end
newdata=[];
for kk=1:n
    SD=D(kk,:);
    [~, pos] = sort(SD);
    index = pos(2 : (k+1) )';
    data1=trainx(index,:);
    newdata=[newdata;data1];
end
sampleset_pair=newdata;
end