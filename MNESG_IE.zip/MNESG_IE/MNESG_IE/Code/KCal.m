function [A,b]=KCal(responsivity,kernel_matrix,kernel_vv,X,K,alpha,sigma_2,Pgamma,Pmu) 
%b=[];
[X_num,~]=size(X);
N1=sum(Pgamma*responsivity.^alpha+(1*Pmu/X_num*K*sigma_2)*kernel_matrix);%ÿһ�еĺ� 1*K; N1=sum(responsivity.^alpha);
N2=sum((-1*Pmu/(K^2*sigma_2))*kernel_vv);
%[m1,n1]=size(N1+N2);
C=(1*Pmu/(K^2*sigma_2))*kernel_vv';
A=diag(N1+N2)+C;
b=(Pgamma*responsivity.^(alpha)+(1*Pmu/X_num*K*sigma_2)*kernel_matrix)'*X;
end