function [X]=Mchol(A,b) 
%Cholesky�ֽⷨ
[M, N] = size(A); 
[M1,N1]=size(b);
X = zeros(M1,N1); 
Y = zeros(M1,N1); 
%Cholesky�ֽ�
for i = 1:N 
    A(i, i) = sqrt(A(i, i)-A(i, 1:i-1) * A(i, 1:i-1)'); 
    if A(i, i) == 0 
        fprintf('�����������')
        break 
    end 
    for j = i+1:N
        A(j, i) = (A(j, i) - A(j, 1:i-1) * A(i, 1:i-1)') / A(i, i); 
    end 
end 
% A 
% b 
%ǰ����
L=tril(A,0);%������
for j = 1:N 
    Y(j,:) = (b(j,:) - A(j, 1:j-1) * Y(1:j-1,:)) / A(j, j); 
end 
% Y 
% 
A=A' ;
for k = N:-1:1 
    X(k,:) = (Y(k,:) - A(k, k+1:N) * X(k+1:N,:)) / A(k, k); 
end 