function [A,b]=Cal(responsivity,X,K,alpha) 
b=[];
N1=sum(responsivity.^alpha);%ÿһ�еĺ� 1*K; N1=sum(responsivity.^alpha);
[m1,n1]=size(N1);
C=(1/(K*K))*ones(m1,n1);
A=diag(N1)+C;
b=(responsivity.^(alpha)+(1/(m1*K)))'*X;



end


